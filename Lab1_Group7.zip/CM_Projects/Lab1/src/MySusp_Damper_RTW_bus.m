Simulink.Bus.cellToObject({
{
    'cmSusp_DamperIn', {
	{'length', 1, 'double', -1, 'real', 'Sample'};
	{'vel',  1, 'double', -1, 'real', 'Sample'};
	{'CtrlIn',  1, 'double', -1, 'real', 'Sample'};
    }
}
{
    'cmSusp_DamperOut', {
	{'Force', 1, 'double', -1, 'real', 'Sample'};
    }
}
% CfgInput Bus
{
    'cmSusp_DamperCfgIn' , {
	{'SuspModID', 1, 'double', -1, 'real', 'Sample'};
    }
}
});
